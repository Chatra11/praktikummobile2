package com.example.daduroll

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val Buttonroll: Button = findViewById(R.id.roll)

        Buttonroll.setOnClickListener {
            rollDice1()
            rollDice2()
            tampil()
        }
        val dadu1: ImageView = findViewById(R.id.dadu1)
        val dadu2 : ImageView = findViewById(R.id.dadu2)
        dadu1.setImageResource(R.drawable.empty_dice)
        dadu2.setImageResource(R.drawable.empty_dice)

    }
    private fun tampil(){
        val pesan1 = Toast.makeText(this, "Selamat anda dapat dadu double!", Toast.LENGTH_LONG)
        val pesan2 = Toast.makeText(this, "Anda belum beruntung!", Toast.LENGTH_LONG)

        if(rollDice1() == rollDice2()){
            pesan1.show()
        }
        else{
            pesan2.show()
        }
    }
    
    private fun rollDice1() : Int {

        val dadu = Dadu(6)
        val diceRoll = dadu.acak()

        val diceImage1: ImageView = findViewById(R.id.dadu1)


        val drawableResource1 = when (diceRoll) {
            1 -> R.drawable.dice_1
            2 -> R.drawable.dice_2
            3 -> R.drawable.dice_3
            4 -> R.drawable.dice_4
            5 -> R.drawable.dice_5
            else -> R.drawable.dice_6
        }

        diceImage1.setImageResource(drawableResource1)
        return diceRoll
    }
    private fun rollDice2() : Int {

        val dadu = Dadu(6)
        val diceRoll = dadu.acak()

        val diceImage2: ImageView = findViewById(R.id.dadu2)

        val drawableResource2 = when (diceRoll) {
            1 -> R.drawable.dice_1
            2 -> R.drawable.dice_2
            3 -> R.drawable.dice_3
            4 -> R.drawable.dice_4
            5 -> R.drawable.dice_5
            else -> R.drawable.dice_6
        }
        diceImage2.setImageResource(drawableResource2)
        return diceRoll
    }
}
class Dadu(private val jumlah: Int) {

    fun acak(): Int {
        return (1..jumlah).random()
    }

}