package com.example.modul3

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.InputMethodManager
import androidx.core.view.isVisible
import com.example.modul3.databinding.ActivityMainBinding
import java.text.NumberFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.hasil.isVisible = false
        binding.Konversi.setOnClickListener{konversiUang()}
        binding.inputUang.setOnKeyListener{view, keyCode,_ ->
            handleKeyEvent(
                view,
                keyCode
            )
        }
    }

    private fun konversiUang(){
        val Hasil = binding.inputUang.text.toString()
        val Nilaiuang = Hasil.toDoubleOrNull()

        if(Nilaiuang == null){
            binding.hasil.text = " "
            return
        }
        val konversi = when (binding.nilaiMataUang.checkedRadioButtonId){
            R.id.Euro -> 15607.31
            R.id.USDollar -> 14370.45
            R.id.japan ->  114.53
            else -> 3832.14
        }
        var uang = Nilaiuang * konversi

        displayKonversi(uang)

    }

    private fun displayKonversi(uang : Double){
        val indonesianLocale = Locale("in", "ID")
        val formattedrupiah = NumberFormat.getCurrencyInstance(indonesianLocale).format(uang)
        binding.hasil.text = getString(R.string.Hasil ,formattedrupiah)
        binding.hasil.isVisible = true
    }
    private fun handleKeyEvent(view: View, keyCode: Int): Boolean {
        if (keyCode == KeyEvent.KEYCODE_ENTER) {
            // Hide the keyboard
            val inputMethodManager =
                getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            inputMethodManager.hideSoftInputFromWindow(view.windowToken, 0)
            return true
        }
        return false
    }

}